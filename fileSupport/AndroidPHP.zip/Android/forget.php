<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
  $email = $_POST['email'];
  $password = $_POST['password'];
  
  $passwordHash = password_hash($password, PASSWORD_DEFAULT);
  
  $sql = "UPDATE users SET password = '$passwordHash' WHERE email = '$email'";
  
  require_once('koneksi.php');
  
  $db = mysqli_query($con,$sql);
  $response = array();
  
  if($db){
	 $response['success'] = "1";
     $response['message'] = "Change Password Success";
     echo json_encode($response);
     die;
  }
  else{
	$response['success'] = "0";
    $response['message'] = "Email Wrong!";
    echo json_encode($response);
    die;
  }
  mysqli_close($con);
 }
?>