<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
  $id = $_POST['id'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  
  $sql = "UPDATE users SET name = '$name', email = '$email' WHERE id = '$id'";
  
  require_once('koneksi.php');
  
  $db = mysqli_query($con,$sql);
  $response = array();
  
  if($db){
	 $response['success'] = "1";
     $response['message'] = "Update Success";
     echo json_encode($response);
     die;
  }
  else{
	$response['success'] = "0";
    $response['message'] = "Update Failed! E-mail already used!";
    echo json_encode($response);
    die;
  }
  mysqli_close($con);
 }
?>