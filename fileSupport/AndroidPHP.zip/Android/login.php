<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
  $email = $_POST['email'];
  $password = $_POST['password'];
  
  $sql = "SELECT * FROM users WHERE email = '$email'";
  
  require_once('koneksi.php');
  
  $db = mysqli_query($con,$sql);
  $response = array();
  
  if(mysqli_num_rows($db) > 0){
      
      $row = mysqli_fetch_assoc($db);
      if(password_verify($password, $row['password'])){
         $response['id'] = $row['id'];
         
         $response['success'] = "1";
         $response['message'] = "Login Success";
         echo json_encode($response);
         die;
      }
      else{
         $response['success'] = "0";
         $response['message'] = "Password Wrong!";
         echo json_encode($response);
         die;
      }
  }
  else{
	$response['success'] = "2";
    $response['message'] = "Email Wrong!";
    echo json_encode($response);
    die;
  }
  mysqli_close($con);
 }
?>