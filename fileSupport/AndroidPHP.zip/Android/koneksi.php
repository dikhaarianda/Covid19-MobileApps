<?php

 define('HOST','localhost');
 define('USER','id19932644_mobile');
 define('PASS','BFI&cI4C{|c1XcUN');
 define('DB','id19932644_mobiledb');

 $con=mysqli_connect(HOST, USER, PASS, DB);


?>  