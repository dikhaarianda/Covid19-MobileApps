<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
  $id = $_POST['id'];
  
  $sql = "DELETE FROM users WHERE id = '$id'";
  
  require_once('koneksi.php');
  
  $db = mysqli_query($con,$sql);
  
  if($db){
	 $response['success'] = "1";
     echo json_encode($response);
     die;
  }
  else{
	$response['success'] = "0";
    echo json_encode($response);
    die;
  }
  mysqli_close($con);
 }
?>