<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  
  $passwordHash = password_hash($password, PASSWORD_DEFAULT);
  
  $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$passwordHash')";
  
  require_once('koneksi.php');
  
  $response = array();
  if(mysqli_query($con,$sql)){
      $response['success'] = "1";
      $response['message'] = "Register Success";
      echo json_encode($response);
      die;
  }else{
      $response['success'] = "0";
      $response['message'] = "Register Failed, E-mail already used";
      echo json_encode($response);
      die;
  }
  mysqli_close($con);
 }
?>