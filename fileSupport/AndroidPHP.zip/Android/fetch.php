<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
  
    $id = $_POST['id'];
  
	$sql = "SELECT * FROM users WHERE id = '$id'";
	
	require_once('koneksi.php');
	
	$db = mysqli_query($con,$sql);
	
	$response = array();
	
	if ($db) { 
	    $row = mysqli_fetch_assoc($db);
		$response['name'] = $row['name'];
		$response['email'] = $row['email'];
		
		$response['success'] = "1";
		$response['message'] = "Fetch Success";
		echo json_encode($response);
		die;
	}
	else{
		$response['success'] = "0";
		$response['message'] = "Server Error";
		echo json_encode($response);
		die;
	}
	mysqli_close($con);
 }
?>